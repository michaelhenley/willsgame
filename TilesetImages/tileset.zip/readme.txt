---------------------------------------------------
Free tileset for 2d sidescrolling platformer games
---------------------------------------------------

File Formats:

Tileset 288x288 (PNG - Tiles resolution 32x32 )
Scene example 640x480 (PNG)

These game assets are being released under the license Creative Commons Zero (CC0).
You may use these assets in personal and commerical projects

Support me on Patreon: 
https://www.patreon.com/gurigraphics

Youtube channel 
https://www.youtube.com/user/gurigraphics

