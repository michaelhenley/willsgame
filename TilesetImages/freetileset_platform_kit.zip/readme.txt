
FREE VERSION

---------------------------------------------------
Free tileset to 2D sidescrolling platformer game
---------------------------------------------------

File Formats:

Tileset 256x256 (PNG - Tiles resolution 32x32 )
Scene example 1 640x480 (PNG)

License:
- These game assets are being released under the license Creative Commons Zero (CC0).
- You may use these assets in personal and commercial projects.
- Attribution is not required but appreciated.  

Support me on Patreon: 
https://www.patreon.com/gurigraphics

Youtube channel 
https://www.youtube.com/user/gurigraphics



------------------------------------------------------------------------------------------------------





FULL VERSION

Starter kit assets- 2D sidescrolling platformer game

Get it on Patreon
https://www.patreon.com/posts/starter-kit-2d-8850337

Get it on Itch-io
https://gurigraphics.itch.io/starter-kit-assets

---------------------------------------------------
Starter kit - 2D sidescrolling platformer game
---------------------------------------------------


Play Demo:
http://starterkit.bitballoon.com/


File Formats:

Tileset 256x256 (PNG - Tiles resolution 32x32 )
Scene example 1 640x480 (PNG)
Scene example 2 640x480 (PNG)

Character animations:
idle - 2 frames
walking - 2 frames
jump - 1 frame
sword - 3 frames
dead - 1 frame

Bat animations
bat - 2 frames

Itens animations
coins - 2 frames
flag - 2 frames

Buttons animations
credits - 2 frames
start - 2 frames

Sounds:
coin sound (mp3)
coin sound (ogg)
jump sound (mp3)
jump sound (ogg)
sword sound (mp3)
sword sound (ogg)

Music:
theme music (midi)
theme music (mp3)
theme music (ogg)



License:
- These game assets are being released under the license Creative Commons 4.0 
https://creativecommons.org/licenses/by/4.0/ 
- You may use these assets in personal and commercial projects.
- Attribution is not required but appreciated.  
- You can not redistribute or sell this. 
- You can use it in multiple projects.

Support me on Patreon: 
https://www.patreon.com/gurigraphics

Youtube channel 
https://www.youtube.com/user/gurigraphics

